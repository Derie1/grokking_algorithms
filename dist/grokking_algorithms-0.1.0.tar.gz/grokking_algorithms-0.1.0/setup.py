# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['grokking_algorithms', 'grokking_algorithms.scripts']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'grokking-algorithms',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Mikhail Davydov',
    'author_email': 'mdavydov83@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
